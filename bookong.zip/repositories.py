import sqlite3
from typing import List, Optional
from models import User, Room, Booking

DB_PATH = "booking_system.db"

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

class UserRepository:
    @staticmethod
    def create(full_name: str, email: str, password_hash: str, role: str) -> User:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO users (full_name, email, password_hash, role)
            VALUES (?, ?, ?, ?)
        """, (full_name, email, password_hash, role))
        conn.commit()
        new_id = cursor.lastrowid
        conn.close()
        return User(id=new_id, full_name=full_name, email=email, role=role)
    
    @staticmethod
    def get_by_id(user_id: int) -> Optional[User]:
        conn = get_db_connection()
        row = conn.execute(
            "SELECT id, full_name, email, role, password_hash FROM users WHERE id = ?",
            (user_id,)
        ).fetchone()
        conn.close()
        return User(**dict(row)) if row else None

    @staticmethod
    def get_by_email(email: str) -> Optional[User]:
        conn = get_db_connection()
        row = conn.execute(
            "SELECT id, full_name, email, role, password_hash FROM users WHERE email = ?",
            (email,)
        ).fetchone()
        conn.close()
        return User(**dict(row)) if row else None

class RoomRepository:
    @staticmethod
    def get_all_by_floor(floor_number: int = 3) -> List[Room]:
        conn = get_db_connection()
        rows = conn.execute("""
            SELECT r.id, r.floor_id, r.room_number, r.capacity,
                   r.equipment_description, r.svg_polygon_id, r.is_active,
                   f.floor_number
            FROM rooms r
            JOIN floors f ON r.floor_id = f.id
            WHERE f.floor_number = ?
            ORDER BY r.room_number ASC
        """, (floor_number,)).fetchall()
        conn.close()
        return [Room(**dict(r)) for r in rows]

    @staticmethod
    def get_by_id(room_id: int) -> Optional[Room]:
        conn = get_db_connection()
        row = conn.execute("""
            SELECT r.id, r.floor_id, r.room_number, r.capacity,
                   r.equipment_description, r.svg_polygon_id, r.is_active,
                   f.floor_number
            FROM rooms r
            JOIN floors f ON r.floor_id = f.id
            WHERE r.id = ?
        """, (room_id,)).fetchone()
        conn.close()
        return Room(**dict(row)) if row else None

    @staticmethod
    def update_status(room_id: int, is_active: int) -> bool:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE rooms SET is_active = ? WHERE id = ?",
            (is_active, room_id)
        )
        conn.commit()
        updated = cursor.rowcount > 0
        conn.close()
        return updated

class BookingRepository:
    @staticmethod
    def get_all() -> List[Booking]:
        conn = get_db_connection()
        rows = conn.execute("""
            SELECT b.id, b.room_id, b.user_id, b.purpose, b.start_time, b.end_time,
                   b.status, b.created_at, b.reminder_sent,
                   r.room_number, u.full_name AS teacher_name, u.email
            FROM bookings b
            JOIN rooms r ON b.room_id = r.id
            JOIN users u ON b.user_id = u.id
            WHERE b.status != 'cancelled'
            ORDER BY b.start_time ASC, b.created_at ASC
        """).fetchall()
        conn.close()
        return [Booking(**dict(r)) for r in rows]

    @staticmethod
    def get_by_id(booking_id: int) -> Optional[Booking]:
        conn = get_db_connection()
        row = conn.execute("""
            SELECT b.id, b.room_id, b.user_id, b.purpose, b.start_time, b.end_time,
                   b.status, b.created_at, b.reminder_sent,
                   r.room_number, u.full_name AS teacher_name, u.email
            FROM bookings b
            JOIN rooms r ON b.room_id = r.id
            JOIN users u ON b.user_id = u.id
            WHERE b.id = ?
        """, (booking_id,)).fetchone()
        conn.close()
        return Booking(**dict(row)) if row else None

    @staticmethod
    def get_confirmed_for_slot(room_id: int, start_dt: str, end_dt: str) -> Optional[dict]:
        conn = get_db_connection()
        row = conn.execute("""
            SELECT b.id, b.user_id, b.purpose, b.start_time, b.end_time,
                   u.full_name AS teacher_name
            FROM bookings b
            JOIN users u ON b.user_id = u.id
            WHERE b.room_id = ?
              AND b.status = 'confirmed'
              AND b.start_time < ?
              AND b.end_time > ?
        """, (room_id, end_dt, start_dt)).fetchone()
        conn.close()
        return dict(row) if row else None

    @staticmethod
    def get_user_existing_booking_in_slot(room_id: int, user_id: int, start_dt: str, end_dt: str) -> Optional[dict]:
        conn = get_db_connection()
        row = conn.execute("""
            SELECT id, status FROM bookings
            WHERE room_id = ?
              AND user_id = ?
              AND status IN ('confirmed', 'queued')
              AND start_time < ?
              AND end_time > ?
        """, (room_id, user_id, end_dt, start_dt)).fetchone()
        conn.close()
        return dict(row) if row else None

    @staticmethod
    def count_queued_for_slot(room_id: int, start_dt: str, end_dt: str) -> int:
        conn = get_db_connection()
        cnt = conn.execute("""
            SELECT COUNT(*) AS cnt FROM bookings
            WHERE room_id = ?
              AND status = 'queued'
              AND start_time < ?
              AND end_time > ?
        """, (room_id, end_dt, start_dt)).fetchone()["cnt"]
        conn.close()
        return cnt

    @staticmethod
    def create(room_id: int, user_id: int, purpose: str, start_time: str, end_time: str, status: str) -> int:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO bookings (room_id, user_id, purpose, start_time, end_time, status, created_at, reminder_sent)
            VALUES (?, ?, ?, ?, ?, ?, DATETIME('now'), 0)
        """, (room_id, user_id, purpose, start_time, end_time, status))
        conn.commit()
        new_id = cursor.lastrowid
        conn.close()
        return new_id

    @staticmethod
    def update_purpose(booking_id: int, purpose: str) -> bool:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE bookings SET purpose = ? WHERE id = ?",
            (purpose, booking_id)
        )
        conn.commit()
        updated = cursor.rowcount > 0
        conn.close()
        return updated

    @staticmethod
    def get_next_queued_for_slot(room_id: int, start_dt: str, end_dt: str) -> Optional[Booking]:
        conn = get_db_connection()
        row = conn.execute("""
            SELECT b.id, b.room_id, b.user_id, b.purpose, b.start_time, b.end_time,
                   b.status, b.created_at, b.reminder_sent,
                   r.room_number, u.full_name AS teacher_name, u.email
            FROM bookings b
            JOIN rooms r ON b.room_id = r.id
            JOIN users u ON b.user_id = u.id
            WHERE b.room_id = ?
              AND b.status = 'queued'
              AND b.start_time < ?
              AND b.end_time > ?
            ORDER BY b.created_at ASC, b.id ASC
            LIMIT 1
        """, (room_id, end_dt, start_dt)).fetchone()
        conn.close()
        return Booking(**dict(row)) if row else None

    @staticmethod
    def delete_and_promote_next(booking: Booking) -> Optional[int]:
        conn = get_db_connection()
        cursor = conn.cursor()
        promoted_id = None

        cursor.execute("DELETE FROM bookings WHERE id = ?", (booking.id,))

        if booking.status == "confirmed":
            next_in_queue = cursor.execute("""
                SELECT id FROM bookings
                WHERE room_id = ?
                  AND status = 'queued'
                  AND start_time < ?
                  AND end_time > ?
                ORDER BY created_at ASC, id ASC
                LIMIT 1
            """, (booking.room_id, booking.end_time, booking.start_time)).fetchone()

            if next_in_queue:
                promoted_id = next_in_queue["id"]
                cursor.execute(
                    "UPDATE bookings SET status = 'confirmed' WHERE id = ?",
                    (promoted_id,)
                )

        conn.commit()
        conn.close()
        return promoted_id